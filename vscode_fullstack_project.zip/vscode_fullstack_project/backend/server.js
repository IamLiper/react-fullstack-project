const express = require("express");
const { Pool } = require("pg");
const app = express();

app.use(express.json());

const pool = new Pool({
  user: process.env.POSTGRES_USER || "user",
  host: process.env.DB_HOST || "db",
  database: process.env.POSTGRES_DB || "tododb",
  password: process.env.POSTGRES_PASSWORD || "pass",
  port: 5432,
});

app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

app.get("/api/items", async (req, res) => {
  try {
    const { rows } = await pool.query("SELECT * FROM items ORDER BY id");
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server Error");
  }
});

app.post("/api/items", async (req, res) => {
  const { name } = req.body;
  try {
    const { rows } = await pool.query(
      "INSERT INTO items (name) VALUES ($1) RETURNING *",
      [name]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server Error");
  }
});

app.listen(3000, () => console.log("Backend rodando na porta 3000"));



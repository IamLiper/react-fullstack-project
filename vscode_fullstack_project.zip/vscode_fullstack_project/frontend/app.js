document.addEventListener("DOMContentLoaded", () => {
    fetchItems();
    checkApiHealth();
});

async function fetchItems() {
    try {
        const response = await fetch("http://localhost:3000/api/items");
        const items = await response.json();
        const itemsList = document.getElementById("itemsList");
        itemsList.innerHTML = "";
        items.forEach(item => {
            const itemDiv = document.createElement("div");
            itemDiv.className = "item";
            itemDiv.innerHTML = `<span>${item.name}</span>`;
            itemsList.appendChild(itemDiv);
        });
    } catch (error) {
        console.error("Erro ao buscar itens:", error);
        document.getElementById("status").innerText = "Status da API: Erro ao carregar itens.";
    }
}

async function addItem() {
    const newItemInput = document.getElementById("newItemInput");
    const itemName = newItemInput.value.trim();
    if (itemName) {
        try {
            await fetch("http://localhost:3000/api/items", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ name: itemName }),
            });
            newItemInput.value = "";
            fetchItems();
        } catch (error) {
            console.error("Erro ao adicionar item:", error);
            document.getElementById("status").innerText = "Status da API: Erro ao adicionar item.";
        }
    }
}

async function checkApiHealth() {
    try {
        const response = await fetch("http://localhost:3000/api/health");
        const data = await response.json();
        document.getElementById("status").innerText = `Status da API: ${data.status}`;
    } catch (error) {
        console.error("Erro ao verificar saúde da API:", error);
        document.getElementById("status").innerText = "Status da API: Offline";
    }
}


